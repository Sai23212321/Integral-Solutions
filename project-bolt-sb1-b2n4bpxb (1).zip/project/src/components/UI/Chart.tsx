import React from 'react';

interface ChartProps {
  type: 'line' | 'donut';
}

const Chart: React.FC<ChartProps> = ({ type }) => {
  // This is a placeholder chart component
  // In a real application, you would use a library like Chart.js, Recharts, etc.
  
  if (type === 'line') {
    return (
      <div className="h-64 w-full flex flex-col justify-center items-center">
        <div className="w-full h-48 flex items-end justify-between px-4">
          {[35, 55, 40, 70, 45, 60, 80].map((height, index) => (
            <div key={index} className="relative group">
              <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-indigo-800 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                {height}%
              </div>
              <div 
                className="w-8 bg-indigo-500 rounded-t transition-all duration-300 hover:bg-indigo-600"
                style={{ height: `${height}%` }}
              ></div>
            </div>
          ))}
        </div>
        <div className="w-full flex justify-between px-4 mt-2 text-xs text-gray-500">
          <span>Jan</span>
          <span>Feb</span>
          <span>Mar</span>
          <span>Apr</span>
          <span>May</span>
          <span>Jun</span>
          <span>Jul</span>
        </div>
      </div>
    );
  }
  
  // Donut chart
  return (
    <div className="h-64 w-full flex justify-center items-center">
      <div className="relative h-44 w-44">
        {/* This is a simple CSS-based donut chart */}
        <svg viewBox="0 0 36 36" className="h-44 w-44">
          <path
            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none"
            stroke="#eee"
            strokeWidth="3"
          />
          <path
            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none"
            stroke="#4f46e5"
            strokeWidth="3"
            strokeDasharray="75, 100"
            strokeDashoffset="25"
          />
          <path
            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none"
            stroke="#10b981"
            strokeWidth="3"
            strokeDasharray="20, 100"
            strokeDashoffset="0"
          />
          <path
            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
            fill="none"
            stroke="#f59e0b"
            strokeWidth="3"
            strokeDasharray="5, 100"
            strokeDashoffset="80"
          />
        </svg>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
          <p className="text-3xl font-bold text-gray-800">75%</p>
          <p className="text-xs text-gray-500">Completed</p>
        </div>
      </div>
      <div className="ml-4">
        <div className="flex items-center mb-2">
          <div className="w-3 h-3 rounded-full bg-indigo-500 mr-2"></div>
          <span className="text-sm text-gray-600">Development</span>
        </div>
        <div className="flex items-center mb-2">
          <div className="w-3 h-3 rounded-full bg-emerald-500 mr-2"></div>
          <span className="text-sm text-gray-600">Design</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-amber-500 mr-2"></div>
          <span className="text-sm text-gray-600">Marketing</span>
        </div>
      </div>
    </div>
  );
};

export default Chart;