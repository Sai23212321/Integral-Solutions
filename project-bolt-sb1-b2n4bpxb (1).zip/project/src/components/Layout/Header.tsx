import React from 'react';
import { Menu, Bell, Search, User, X } from 'lucide-react';

interface HeaderProps {
  toggleSidebar: () => void;
  isDetailPaneOpen: boolean;
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar, isDetailPaneOpen }) => {
  return (
    <header className="bg-white h-16 flex items-center justify-between px-4 border-b border-gray-200 shadow-sm z-10">
      <div className="flex items-center">
        <button 
          className="lg:hidden mr-2 p-2 rounded-full hover:bg-gray-100 transition-colors"
          onClick={toggleSidebar}
          aria-label="Toggle sidebar"
        >
          <Menu size={20} />
        </button>
        <div className="relative hidden md:block">
          <input 
            type="text" 
            placeholder="Search..."
            className="w-64 pl-9 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
          <Search size={18} className="absolute left-3 top-2.5 text-gray-400" />
        </div>
      </div>
      <div className="flex items-center space-x-4">
        <button className="p-2 rounded-full hover:bg-gray-100 transition-colors" aria-label="Notifications">
          <Bell size={20} />
        </button>
        <div className="h-8 w-px bg-gray-300"></div>
        <div className="flex items-center space-x-2">
          <div className="hidden sm:block">
            <p className="text-sm font-medium">Alex Johnson</p>
            <p className="text-xs text-gray-500">Administrator</p>
          </div>
          <div className="h-9 w-9 bg-indigo-600 rounded-full flex items-center justify-center text-white">
            <User size={18} />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;