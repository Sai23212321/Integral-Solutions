import React from 'react';
import { Layers, TrendingUp, Users, DollarSign, Clock, ArrowRight } from 'lucide-react';
import Card from '../UI/Card';
import StatusCard from '../UI/StatusCard';
import Chart from '../UI/Chart';

interface MainContentProps {
  isSidebarCollapsed: boolean;
  isDetailPaneOpen: boolean;
  onItemClick: (id: string) => void;
}

const MainContent: React.FC<MainContentProps> = ({ 
  isSidebarCollapsed, 
  isDetailPaneOpen, 
  onItemClick 
}) => {
  const projects = [
    { id: '1', name: 'Website Redesign', status: 'In Progress', completion: 75, dueDate: '2025-10-15' },
    { id: '2', name: 'Mobile App Development', status: 'Planning', completion: 20, dueDate: '2025-12-01' },
    { id: '3', name: 'Marketing Campaign', status: 'Completed', completion: 100, dueDate: '2025-09-30' },
    { id: '4', name: 'E-commerce Platform', status: 'In Progress', completion: 60, dueDate: '2025-11-15' },
  ];

  return (
    <main 
      className={`flex-1 overflow-auto transition-all duration-300 px-4 py-6 ${
        isDetailPaneOpen ? 'mr-96' : ''
      }`}
    >
      <h1 className="text-2xl font-semibold text-gray-900 mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatusCard 
          title="Total Projects" 
          value="24" 
          trend="+12%" 
          icon={<Layers className="text-indigo-500" />} 
          trendUp={true}
        />
        <StatusCard 
          title="Team Members" 
          value="16" 
          trend="+2%" 
          icon={<Users className="text-emerald-500" />}
          trendUp={true} 
        />
        <StatusCard 
          title="Total Budget" 
          value="$420,500" 
          trend="-5%" 
          icon={<DollarSign className="text-amber-500" />}
          trendUp={false} 
        />
        <StatusCard 
          title="Hours Logged" 
          value="1,250" 
          trend="+18%" 
          icon={<Clock className="text-rose-500" />}
          trendUp={true}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card title="Revenue Overview">
          <Chart type="line" />
        </Card>
        <Card title="Project Distribution">
          <Chart type="donut" />
        </Card>
      </div>
      
      <Card title="Current Projects">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-gray-500 border-b">
                <th className="pb-3 font-medium">Project Name</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">Completion</th>
                <th className="pb-3 font-medium">Due Date</th>
                <th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((project) => (
                <tr key={project.id} className="border-b border-gray-100">
                  <td className="py-4 font-medium">{project.name}</td>
                  <td className="py-4">
                    <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                      project.status === 'Completed' ? 'bg-green-100 text-green-800' :
                      project.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {project.status}
                    </span>
                  </td>
                  <td className="py-4">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          project.status === 'Completed' ? 'bg-green-500' :
                          project.completion > 50 ? 'bg-blue-500' : 'bg-amber-500'
                        }`}
                        style={{ width: `${project.completion}%` }}
                      ></div>
                    </div>
                    <span className="text-xs text-gray-500 mt-1">{project.completion}%</span>
                  </td>
                  <td className="py-4 text-sm text-gray-600">{project.dueDate}</td>
                  <td className="py-4">
                    <button 
                      onClick={() => onItemClick(project.id)}
                      className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-medium text-sm"
                    >
                      Details <ArrowRight size={16} className="ml-1" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </main>
  );
};

export default MainContent;