import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import MainContent from './MainContent';
import DetailPane from './DetailPane';

const Layout: React.FC = () => {
  const [isSidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isDetailPaneOpen, setDetailPaneOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<string | null>(null);

  const toggleSidebar = () => {
    setSidebarCollapsed(!isSidebarCollapsed);
  };

  const toggleDetailPane = () => {
    setDetailPaneOpen(!isDetailPaneOpen);
  };

  const handleItemClick = (itemId: string) => {
    setSelectedItem(itemId);
    setDetailPaneOpen(true);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggle={toggleSidebar} 
      />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header 
          toggleSidebar={toggleSidebar} 
          isDetailPaneOpen={isDetailPaneOpen}
        />
        <div className="flex flex-1 overflow-hidden">
          <MainContent 
            isSidebarCollapsed={isSidebarCollapsed}
            isDetailPaneOpen={isDetailPaneOpen}
            onItemClick={handleItemClick}
          />
          {isDetailPaneOpen && (
            <DetailPane 
              selectedItem={selectedItem}
              onClose={toggleDetailPane} 
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default Layout;