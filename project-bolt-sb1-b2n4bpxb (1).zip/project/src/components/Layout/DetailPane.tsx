import React from 'react';
import { X, Clock, Calendar, Users, CheckSquare, MessageSquare } from 'lucide-react';

interface DetailPaneProps {
  selectedItem: string | null;
  onClose: () => void;
}

const DetailPane: React.FC<DetailPaneProps> = ({ selectedItem, onClose }) => {
  // Mock data - in a real app, this would come from API or props
  const projectDetails = {
    id: selectedItem,
    name: selectedItem === '1' ? 'Website Redesign' : 
          selectedItem === '2' ? 'Mobile App Development' : 
          selectedItem === '3' ? 'Marketing Campaign' : 
          selectedItem === '4' ? 'E-commerce Platform' : 'Unknown Project',
    status: selectedItem === '3' ? 'Completed' : selectedItem === '2' ? 'Planning' : 'In Progress',
    completion: selectedItem === '3' ? 100 : selectedItem === '1' ? 75 : selectedItem === '4' ? 60 : 20,
    dueDate: selectedItem === '1' ? '2025-10-15' : 
             selectedItem === '2' ? '2025-12-01' : 
             selectedItem === '3' ? '2025-09-30' : 
             selectedItem === '4' ? '2025-11-15' : 'Unknown',
    description: "This project aims to create a modern, user-friendly interface with improved functionality and performance. The team is working on multiple components simultaneously with regular reviews and updates.",
    tasks: [
      { id: 1, title: "Design system creation", completed: true },
      { id: 2, title: "Frontend implementation", completed: selectedItem === '3' },
      { id: 3, title: "Backend integration", completed: selectedItem === '3' },
      { id: 4, title: "User testing", completed: false },
      { id: 5, title: "Deployment", completed: false },
    ],
    teamMembers: [
      { id: 1, name: "Alex Johnson", role: "Project Manager", avatar: "A" },
      { id: 2, name: "Sam Wilson", role: "Designer", avatar: "S" },
      { id: 3, name: "Taylor Lee", role: "Developer", avatar: "T" },
      { id: 4, name: "Jamie Chen", role: "QA Engineer", avatar: "J" },
    ],
    recentActivity: [
      { id: 1, action: "Updated project timeline", user: "Alex", time: "2 hours ago" },
      { id: 2, action: "Added new task", user: "Taylor", time: "Yesterday" },
      { id: 3, action: "Completed design review", user: "Sam", time: "2 days ago" },
    ],
  };

  const statusColor = 
    projectDetails.status === 'Completed' ? 'bg-green-100 text-green-800' :
    projectDetails.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
    'bg-yellow-100 text-yellow-800';

  return (
    <div className="w-96 bg-white border-l border-gray-200 overflow-auto shadow-lg animate-slideIn">
      <div className="sticky top-0 bg-white z-10 border-b border-gray-200">
        <div className="flex items-center justify-between p-4">
          <h2 className="text-lg font-semibold text-gray-900">Project Details</h2>
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-100 transition-colors"
            aria-label="Close details"
          >
            <X size={20} />
          </button>
        </div>
      </div>
      
      <div className="p-4">
        <h1 className="text-xl font-bold text-gray-900 mb-2">{projectDetails.name}</h1>
        <div className="flex items-center mb-4">
          <span className={`px-2 py-1 text-xs rounded-full ${statusColor}`}>
            {projectDetails.status}
          </span>
          <div className="ml-auto flex items-center text-gray-500 text-sm">
            <Clock size={14} className="mr-1" /> 
            <span>Due: {projectDetails.dueDate}</span>
          </div>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">Completion</span>
            <span className="text-sm text-gray-500">{projectDetails.completion}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full ${
                projectDetails.status === 'Completed' ? 'bg-green-500' :
                projectDetails.completion > 50 ? 'bg-blue-500' : 'bg-amber-500'
              }`}
              style={{ width: `${projectDetails.completion}%` }}
            ></div>
          </div>
        </div>
        
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-900 mb-2">Description</h3>
          <p className="text-sm text-gray-600">{projectDetails.description}</p>
        </div>
        
        <div className="mb-6">
          <div className="flex items-center mb-3">
            <CheckSquare size={16} className="text-indigo-600 mr-2" />
            <h3 className="text-sm font-semibold text-gray-900">Tasks</h3>
          </div>
          <ul className="space-y-2">
            {projectDetails.tasks.map(task => (
              <li key={task.id} className="flex items-start">
                <div className={`w-4 h-4 mt-0.5 mr-2 rounded-sm border ${
                  task.completed ? 'bg-indigo-600 border-indigo-600' : 'border-gray-300'
                } flex items-center justify-center`}>
                  {task.completed && <span className="text-white text-xs">✓</span>}
                </div>
                <span className={`text-sm ${task.completed ? 'line-through text-gray-400' : 'text-gray-700'}`}>
                  {task.title}
                </span>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="mb-6">
          <div className="flex items-center mb-3">
            <Users size={16} className="text-indigo-600 mr-2" />
            <h3 className="text-sm font-semibold text-gray-900">Team</h3>
          </div>
          <ul className="space-y-3">
            {projectDetails.teamMembers.map(member => (
              <li key={member.id} className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-800 flex items-center justify-center font-medium text-sm mr-3">
                  {member.avatar}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-800">{member.name}</p>
                  <p className="text-xs text-gray-500">{member.role}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
        
        <div>
          <div className="flex items-center mb-3">
            <MessageSquare size={16} className="text-indigo-600 mr-2" />
            <h3 className="text-sm font-semibold text-gray-900">Recent Activity</h3>
          </div>
          <ul className="space-y-3">
            {projectDetails.recentActivity.map(activity => (
              <li key={activity.id} className="text-sm">
                <p className="text-gray-800">
                  <span className="font-medium">{activity.user}</span> {activity.action}
                </p>
                <p className="text-xs text-gray-500">{activity.time}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DetailPane;